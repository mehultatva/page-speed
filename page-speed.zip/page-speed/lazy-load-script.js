/*Include lazy load js*/
<?php 
$agent = $_SERVER["HTTP_USER_AGENT"];

if( !preg_match('/MSIE (\d+\.\d+);/', $agent) ) {
  ?>
    <script type="text/javascript" src="<?php echo $rootUrl ?>lazy-load.js"></script>  
<?php } ?>

<script>

    if (!(/Edge\/\d./i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(
                    navigator.userAgent) || /MSIE 10/i.test(navigator.userAgent))) {
        LazyLoad.init();
    }
</script>


// To prevent Lazy load and change banner image in IE and EDGE
if (/Edge\/\d./i.test(navigator.userAgent) || /MSIE 9/i.test(navigator.userAgent) || /rv:11.0/i.test(
        navigator.userAgent) || /MSIE 10/i.test(navigator.userAgent)) {
    if ($("html").hasClass('ie') || $("html").hasClass('edge')) {
        $(".js-lazy-image").each(function () {
            $(this).attr("src", $(this).attr('data-src'));
            $(this).removeAttr('data-src');
            $(this).removeClass("js-lazy-image");
        });
    }
}

